AMPEL_SETTINGS = {
    'relations':[
        {'PersonPerson': False},
        {'PersonInstitution': False},
        {'PersonPlace': False},
        {'PersonWork': False},
        {'PersonEvent': False},
        {'InstitutionInstitution': False},
        {'InstitutionPlace': False},
        {'InstitutionWork': False},
        {'InstitutionEvent': False},
        {'PlacePlace': False},
        {'PlaceWork': False},
        {'PlaceEvent': False},
        {'WorkWork': False},
        {'EventWork': False},
        {'EventEvent': False},
    ],
    'entities':
    [ 
        {'Person': False},
        {'Institution': False},
        {'Place': False},
        {'Event': False},
        {'Work': False},
    ]
}